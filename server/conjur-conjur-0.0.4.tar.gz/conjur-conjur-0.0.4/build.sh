#!/usr/bin/env bash
set -eo pipefail

IMAGE_NAME=puppet-conjur-build
IMAGE_TAG=0.1

docker build -t $IMAGE_NAME:$IMAGE_TAG .
docker run --rm -v `pwd`:/module $IMAGE_NAME:$IMAGE_TAG